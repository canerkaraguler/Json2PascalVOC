JsonToPascalVoc is a Python library for converting some special Json strings to PascalVOC format XML files.


